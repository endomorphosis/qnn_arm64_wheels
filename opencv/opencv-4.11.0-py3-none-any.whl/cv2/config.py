import os

BINARIES_PATHS = [
    'C:/Users/DFS/Downloads/opencv_build/bin/Release'
] + BINARIES_PATHS
