PYTHON_EXTENSIONS_PATHS = [
    'C:/Users/DFS/Downloads/opencv_build/lib/python3/Release'
] + PYTHON_EXTENSIONS_PATHS
